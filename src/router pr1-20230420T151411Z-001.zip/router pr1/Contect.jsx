import React from 'react'
import Navbar from './Navbar'

function Contect() {
  return (
    <div>
        <Navbar/>
      <h1>contect page</h1>
    </div>
  )
}

export default Contect
