import './App.css';
import Navbar from './Navbar';
import './Nav.css'
import Allroute from './Allroute';

function App() {
  return (
    <div className="App">
     <Allroute/>
    </div>
  );
}

export default App;
